package demo;

public class FindShortestSubstringHavingAllTheCharacterOfFirstString {

    public static void main(String[] args) {
        String a = "xyz";
        String b = "defxyllllz";
        // String b = "aaaa";
        StringBuilder resultBuilder = new StringBuilder();
        char strA[] = a.toCharArray();
        int i = 0;
        String result = null;
        boolean flagToBreak = false;
        boolean minmumOneStringFound = false;
        // if string 'a' has length greater then string 'b', it doesn't make sense to find substring in 'b'
        for (int j = 0; strA.length <= b.length() && j < b.length();) {
            // while iterating if end of string b has reached then break out from the loop
            for (; i < strA.length && j < b.length();) {
                // if number of character left in string 'b' to iterate is less then the number of character left
                // in string 'a' to match break out
                if ((b.length() - j) < (strA.length - i)) {
                    flagToBreak = true;
                    break;
                }
                if (b.charAt(j) == strA[i]) {
                    i++;
                }
                // found a start character of string 'a', so start putting characters from string 'b' into resultBuilder
                if (i > 0) {
                    resultBuilder.append(b.charAt(j));
                }
                j++;
                // if end of string 'a' is reached we have substring from string 'b' that has all the characters from
                // string 'a'
                if (i == a.length()) {
                    i = 0;
                    // if it is first string found or is smaller in length then the previously found string replace
                    // result with this
                    if (result == null || result.length() > resultBuilder.length()) {
                        minmumOneStringFound = true;
                        result = resultBuilder.toString();
                    }
                    resultBuilder.delete(0, resultBuilder.length());
                }
            }
            if (flagToBreak) {
                break;
            }
        }
        // minimum one string should be found and result should have length greater then zero
        System.out.println(minmumOneStringFound && result.length() > 0 ? result : "no result to display");
    }

}
